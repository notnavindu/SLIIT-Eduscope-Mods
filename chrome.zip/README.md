# SLIIT Eduscope Mod v3.0

A Simple Chrome Extension with a few simple mods for SLIIT's Eduscope video platform.

## Features

- Change video playback speed (0.5x, 1x, 2x, 6x)
- Theater mode
- Save video playback time
- Download videos
- Prevent the page from scrolling when the spacebar is pressed

### Firefox

Latest version (v3) is not tested or ported to firefox yet. Waiting till Sem 1 finals are over :/

Did anyone ask for this? No.
