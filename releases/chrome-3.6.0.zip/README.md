# SLIIT Eduscope Mod v3.5.0

A Simple Chrome Extension with a few simple mods for SLIIT's Eduscope video platform.

## Important update regarding lecture downloading

The downloader did stop working due to a stupid bug (that I obviously wrote). HOWEVER, I have developed an entirely new version of the downloader and its in the final stages of going public. Meanwhile, please feel free to join the waitlist for it here https://downloader-onboarding.vercel.app/

## Features

- Change video playback speed (0.5x, 1x, 2x, 6x)
- Theater mode
- Save video playback time
- Prevent the page from scrolling when the spacebar is pressed

### Supported Browsers

- Chrome
- Brave
- Edge

Did anyone ask for this? No.
