# SLIIT Eduscope Mod

A Simple Chrome Extension (need help with Firefox) with a few simple mods for SLIIT's Eduscope video platform.

## Features

    - Change video playback speed (0.5x, 1x, 2x, 6x)
    - Prevent the page from scrolling when the spacebar is pressed
    - Hide the gigantic "eduscope" header

### Upcoming Features

    - Dark Theme Mod

Did anyone ask for this? No.
